#include <iostream>

int main() {
	std::cout << "Gabriel" << std::endl;
	std::cout << "Ontario" << std::endl;
	std::cout << "Canada" << std::endl;
}